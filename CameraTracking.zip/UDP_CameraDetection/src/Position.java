
public class Position {
	static final int TOP_LEFT = 0;
	static final int TOP_RIGHT = 1;
	static final int BOTTOM_LEFT = 2;
	static final int BOTTOM_RIGHT = 3;
	static final int CENTER = 4;
}
